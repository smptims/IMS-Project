import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-mail-list',
  templateUrl: './user-mail-list.page.html',
  styleUrls: ['./user-mail-list.page.scss'],
})
export class UserMailListPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
