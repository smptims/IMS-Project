import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-send-mail-sms-view',
  templateUrl: './send-mail-sms-view.page.html',
  styleUrls: ['./send-mail-sms-view.page.scss'],
})
export class SendMailSmsViewPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
