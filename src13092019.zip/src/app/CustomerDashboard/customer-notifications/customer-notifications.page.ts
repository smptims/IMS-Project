import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-notifications',
  templateUrl: './customer-notifications.page.html',
  styleUrls: ['./customer-notifications.page.scss'],
})
export class CustomerNotificationsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
