import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-send-sms',
  templateUrl: './customer-send-sms.page.html',
  styleUrls: ['./customer-send-sms.page.scss'],
})
export class CustomerSendSmsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
