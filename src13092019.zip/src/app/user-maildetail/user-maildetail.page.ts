import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-maildetail',
  templateUrl: './user-maildetail.page.html',
  styleUrls: ['./user-maildetail.page.scss'],
})
export class UserMaildetailPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
